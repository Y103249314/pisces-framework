#!/bin/bash

domain=${1:-'group1'}
port=${2:-'0'}
default_base=${3:-'/data/fastdfs/pisces/storage'}
tracker_server1=${4:-'192.168.1.7:22122'}
tracker_server2=${5:-${tracker_server1}}

function parse_options() {
  options=$(getopt -o b::,d:,p:,t: -l basepath::,domain:,port:,tracker1:,tracker2:: -- $@)
  eval set -- $options

  while true; do
      case "$1" in
        -b | --basepath)
            default_base=$2
            shift 2
            ;;
        -d | --domain)
            domain=$2
            shift 2
            ;;
	-p| --port)
            port=$2
            shift 2
            ;;
        -t | --tracker1)
            tracker_server1=$2
            tracker_server2=${tracker_server1}
            shift 2
            ;;
        --tracker2)
            tracker_server2=$2
            shift 2
            ;;
        --)
            shift
            break
            ;;
        *)
            echo "Usage: $0 [-b|--basepath <path>] -t|--tracker1 <tracker_server1> [--tracker2 <tracker_server2>]"
            exit 1
            ;;
      esac
  done
}

function deploy_storage() {
  port_file=fdfs.storage.port.next.txt
  conf_tmpl=fdfs.storage.conf.template
  service_tmpl=fdfs.storage.service.template

  group=${domain}
  fport=`cat ${port_file}`
  base_path=${default_base}.${domain}
  conf_file=/etc/fdfs/pisces/storage.${domain}.conf
  service_name=fdfs_storaged.${domain}
  service_file=/etc/init.d/${service_name}
  
  if [ -f "${service_file}" ]; then
    echo "service ${service_name} exists and skipped."
    continue
  fi

  if [ "${port}" -lt "${fport}" ]; then
    port=${fport}
  fi
  
  echo $((port+1)) > ${port_file} # port+1并回写
  mkdir -p ${base_path}
  mkdir -p /etc/fdfs/pisces
  cp ${conf_tmpl} ${conf_file}
  cp ${service_tmpl} ${service_file}
  
  sed -i "s@{group_name}@${group}@" ${conf_file} 
  sed -i "s@{port}@${port}@" ${conf_file}
  sed -i "s@{base_path}@${base_path}@" ${conf_file}
  sed -i "s@{tracker_server1}@${tracker_server1}@" ${conf_file}
  sed -i "s@{tracker_server2}@${tracker_server2}@" ${conf_file}
  
  sed -i "s@{storage_conf}@${conf_file}@" ${service_file}

  firewall-cmd --zone=public --add-port=${port}/tcp --permanent
  firewall-cmd --reload
  
  chmod +x ${service_file}
  chkconfig --add ${service_name}
  service ${service_name} start
}

parse_options $@
deploy_storage $@

echo
echo completed!
echo

